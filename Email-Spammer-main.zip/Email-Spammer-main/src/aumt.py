import os
import sys


os.system("cd && rm -rf AutoUpdateMyTools")
os.system("cd && cd Email-Spammer && python custom_spam.py")
